package sg.edu.np.mad.exercise2;

public class User {
    String name;
    String description;
    Integer id;
    boolean followed;
}
